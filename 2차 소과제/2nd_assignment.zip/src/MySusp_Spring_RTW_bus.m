Simulink.Bus.cellToObject({
{
    'cmSusp_SpringIn', {
	{'length', 1, 'double', -1, 'real', 'Sample'};
	{'vel',  1, 'double', -1, 'real', 'Sample'};
	{'CtrlIn',  1, 'double', -1, 'real', 'Sample'};
    }
}
{
    'cmSusp_SpringOut', {
	{'Force', 1, 'double', -1, 'real', 'Sample'};
    }
}
% CfgInput Bus
{
    'cmSusp_SpringCfgIn' , {
	{'SuspModID', 1, 'double', -1, 'real', 'Sample'};
    }
}
});
